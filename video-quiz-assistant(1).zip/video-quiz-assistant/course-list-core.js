(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  root.VQACourseList = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  "use strict";

  function parseProgress(text) {
    const match = String(text || "").match(/已看\s*[：:]?\s*(\d+(?:\.\d+)?)\s*%/i);
    return match ? Number(match[1]) : null;
  }

  function findNextCourse(courses) {
    return courses.find((course) => Number.isFinite(course.progress) && course.progress < 100) || null;
  }

  return { parseProgress, findNextCourse };
});
