const DEFAULTS = {
  enabledSites: {}, playbackRate: 1, actionDelay: 800, autoNext: true,
  autoSubmit: true, showBadge: true, answerRules: "", questionSelector: "",
  optionSelector: "", submitSelector: "", nextSelector: ""
};
const fields = ["playbackRate", "actionDelay", "autoNext", "autoSubmit", "showBadge", "answerRules", "questionSelector", "optionSelector", "submitSelector", "nextSelector"];

async function load() {
  const config = await chrome.storage.local.get(DEFAULTS);
  for (const key of fields) {
    const el = document.querySelector(`#${key}`);
    if (el.type === "checkbox") el.checked = config[key];
    else el.value = config[key];
  }
}

async function save() {
  const values = {};
  for (const key of fields) {
    const el = document.querySelector(`#${key}`);
    values[key] = el.type === "checkbox" ? el.checked : el.value;
  }
  values.playbackRate = Math.min(4, Math.max(0.25, Number(values.playbackRate) || 1));
  values.actionDelay = Math.min(10000, Math.max(200, Number(values.actionDelay) || 800));
  await chrome.storage.local.set(values);
  const saved = document.querySelector("#saved");
  saved.textContent = "已保存";
  setTimeout(() => { saved.textContent = ""; }, 1800);
}

async function reset() {
  const enabledSites = (await chrome.storage.local.get(DEFAULTS)).enabledSites;
  await chrome.storage.local.set({ ...DEFAULTS, enabledSites });
  await load();
}

document.querySelector("#save").addEventListener("click", save);
document.querySelector("#reset").addEventListener("click", reset);
load();
