(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  root.VQAQuiz = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  "use strict";

  function selectionCount(type, optionCount) {
    if (optionCount <= 0) return 0;
    return type === "multiple" ? Math.min(2, optionCount) : 1;
  }

  function pickRandomIndexes(optionCount, count, random = Math.random) {
    const pool = Array.from({ length: optionCount }, (_, index) => index);
    const chosen = [];
    while (pool.length && chosen.length < count) {
      const position = Math.floor(random() * pool.length);
      chosen.push(pool.splice(Math.min(position, pool.length - 1), 1)[0]);
    }
    return chosen;
  }

  function resultButtonText(labels) {
    const normalized = labels.map((label) => String(label || "").replace(/\s+/g, ""));
    if (normalized.some((label) => label.includes("确认"))) return "确认";
    if (normalized.some((label) => label.includes("关闭"))) return "关闭";
    return null;
  }

  return { selectionCount, pickRandomIndexes, resultButtonText };
});
