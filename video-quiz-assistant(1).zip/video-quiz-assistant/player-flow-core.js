(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  root.VQAPlayerFlow = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  "use strict";

  function finishAction({ hasCloseButton, courseTabId, playerTabId }) {
    if (hasCloseButton) return "close-dialog";
    if (Number.isInteger(courseTabId) && courseTabId !== playerTabId) return "close-player-tab";
    return "go-back";
  }

  function playbackAction({ readyState, paused, ended, attemptPending }) {
    if (ended || !paused || attemptPending) return "none";
    if (readyState < 2) return "wait-for-data";
    return "try-play";
  }

  return { finishAction, playbackAction };
});
