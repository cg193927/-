const assert = require("node:assert/strict");
const { selectionCount, pickRandomIndexes, resultButtonText } = require("../quiz-core.js");

assert.equal(selectionCount("single", 4), 1);
assert.equal(selectionCount("multiple", 4), 2);
assert.equal(selectionCount("multiple", 1), 1);
assert.deepEqual(pickRandomIndexes(4, 1, () => 0), [0]);
assert.deepEqual(pickRandomIndexes(4, 2, () => 0), [0, 1]);
assert.equal(new Set(pickRandomIndexes(4, 2)).size, 2);
assert.equal(resultButtonText(["关闭", "确认"]), "确认");
assert.equal(resultButtonText(["关闭"]), "关闭");
console.log("quiz-core tests OK");
