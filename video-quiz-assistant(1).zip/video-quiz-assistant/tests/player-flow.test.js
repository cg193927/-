const assert = require("node:assert/strict");
const { finishAction, playbackAction } = require("../player-flow-core.js");

assert.equal(finishAction({ hasCloseButton: true, courseTabId: 1, playerTabId: 2 }), "close-dialog");
assert.equal(finishAction({ hasCloseButton: false, courseTabId: 1, playerTabId: 2 }), "close-player-tab");
assert.equal(finishAction({ hasCloseButton: false, courseTabId: 1, playerTabId: 1 }), "go-back");
assert.equal(finishAction({ hasCloseButton: false, courseTabId: null, playerTabId: 2 }), "go-back");
assert.equal(playbackAction({ readyState: 0, paused: true, ended: false, attemptPending: false }), "wait-for-data");
assert.equal(playbackAction({ readyState: 2, paused: true, ended: false, attemptPending: false }), "try-play");
assert.equal(playbackAction({ readyState: 4, paused: false, ended: false, attemptPending: false }), "none");
assert.equal(playbackAction({ readyState: 4, paused: true, ended: false, attemptPending: true }), "none");
console.log("player-flow tests OK");
