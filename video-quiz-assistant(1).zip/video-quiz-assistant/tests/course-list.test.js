const assert = require("node:assert/strict");
const { parseProgress, findNextCourse } = require("../course-list-core.js");

assert.equal(parseProgress("mp4（已看： 100 %）"), 100);
assert.equal(parseProgress("mp4（已看：0%）"), 0);
assert.equal(parseProgress("没有进度"), null);

const next = findNextCourse([
  { name: "第一课", progress: 100 },
  { name: "第二课", progress: 45 },
  { name: "第三课", progress: 0 }
]);
assert.equal(next.name, "第二课");

assert.equal(findNextCourse([{ name: "完成", progress: 100 }]), null);
console.log("course-list tests OK");
