const DEFAULTS = {
  enabledSites: {}, playbackRate: 1, actionDelay: 800, autoNext: true,
  autoSubmit: true, showBadge: true, answerRules: "", questionSelector: "",
  optionSelector: "", submitSelector: "", nextSelector: ""
};

const enabled = document.querySelector("#enabled");
const playbackRate = document.querySelector("#playbackRate");
const status = document.querySelector("#status");
let activeTab;
let siteKey;

async function init() {
  [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!activeTab?.url || !/^https?:/.test(activeTab.url)) {
    status.textContent = "请在普通网页上使用此扩展。";
    enabled.disabled = true;
    return;
  }
  siteKey = new URL(activeTab.url).origin;
  const config = await chrome.storage.local.get(DEFAULTS);
  enabled.checked = Boolean(config.enabledSites[siteKey]);
  playbackRate.value = String(config.playbackRate);
  status.textContent = enabled.checked ? `已在 ${new URL(activeTab.url).hostname} 启用` : "当前网站尚未启用";
}

async function saveAndRun() {
  if (!activeTab || !siteKey) return;
  const config = await chrome.storage.local.get(DEFAULTS);
  const enabledSites = { ...config.enabledSites, [siteKey]: enabled.checked };
  await chrome.storage.local.set({ enabledSites, playbackRate: Number(playbackRate.value) });
  try {
    await chrome.tabs.sendMessage(activeTab.id, { type: "VQA_RUN" });
    status.textContent = enabled.checked ? "已启动" : "已暂停";
  } catch {
    try {
      await chrome.scripting.executeScript({ target: { tabId: activeTab.id, allFrames: true }, files: ["course-list-core.js"] });
      await chrome.scripting.executeScript({ target: { tabId: activeTab.id, allFrames: true }, files: ["player-flow-core.js"] });
      await chrome.scripting.executeScript({ target: { tabId: activeTab.id, allFrames: true }, files: ["quiz-core.js"] });
      await chrome.scripting.executeScript({ target: { tabId: activeTab.id, allFrames: true }, files: ["content.js"] });
      status.textContent = enabled.checked ? "已注入并启动" : "已暂停";
    } catch (error) {
      status.textContent = `无法运行：${error.message}`;
    }
  }
}

enabled.addEventListener("change", saveAndRun);
playbackRate.addEventListener("change", saveAndRun);
document.querySelector("#start").addEventListener("click", saveAndRun);
document.querySelector("#settings").addEventListener("click", () => chrome.runtime.openOptionsPage());
init();
