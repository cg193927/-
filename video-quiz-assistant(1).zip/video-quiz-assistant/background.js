chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!Number.isInteger(sender.tab?.id) || !message?.type) return;

  if (message.type === "VQA_REGISTER_COURSE_TAB") {
    registerCourseTab(message.siteKey, sender.tab.id).then(sendResponse);
    return true;
  }

  if (message.type === "VQA_SHOULD_RUN") {
    shouldRunInTab(sender.tab, message.directEnabled).then(sendResponse);
    return true;
  }

  if (message.type === "VQA_SET_TAB_PAUSED") {
    setTabPaused(sender.tab.id, Boolean(message.paused)).then(sendResponse);
    return true;
  }

  if (message.type === "VQA_STOP_AUTOMATION") {
    stopAutomation(sender.tab, message.siteKey).then(sendResponse);
    return true;
  }

  if (message.type === "VQA_PLAYER_FINISHED") {
    finishPlayer(message.siteKey, sender.tab).then(sendResponse);
    return true;
  }
});

chrome.tabs.onRemoved.addListener((tabId) => {
  removeCourseTab(tabId).catch(() => {});
});

async function getCourseState() {
  return (await chrome.storage.session.get({ courseTabBySite: {}, lastCourseTabId: null, pausedTabIds: [] }));
}

async function registerCourseTab(siteKey, tabId) {
  const state = await getCourseState();
  await chrome.storage.session.set({
    courseTabBySite: { ...state.courseTabBySite, [siteKey]: tabId },
    lastCourseTabId: tabId
  });
  return { ok: true };
}

async function removeCourseTab(tabId) {
  const state = await getCourseState();
  const entries = Object.entries(state.courseTabBySite).filter(([, value]) => value !== tabId);
  await chrome.storage.session.set({
    courseTabBySite: Object.fromEntries(entries),
    lastCourseTabId: state.lastCourseTabId === tabId ? null : state.lastCourseTabId,
    pausedTabIds: state.pausedTabIds.filter((id) => id !== tabId)
  });
}

async function shouldRunInTab(tab, directEnabled) {
  const state = await getCourseState();
  const paused = state.pausedTabIds.includes(tab.id);
  if (directEnabled) return { enabled: true, paused };
  const courseIds = new Set(Object.values(state.courseTabBySite));
  return { enabled: courseIds.has(tab.id) || courseIds.has(tab.openerTabId), paused };
}

async function setTabPaused(tabId, paused) {
  const state = await getCourseState();
  const pausedTabIds = new Set(state.pausedTabIds);
  if (paused) pausedTabIds.add(tabId);
  else pausedTabIds.delete(tabId);
  await chrome.storage.session.set({ pausedTabIds: [...pausedTabIds] });
  await chrome.tabs.sendMessage(tabId, { type: "VQA_APPLY_PAUSED", paused }).catch(() => {});
  return { ok: true, paused };
}

async function stopAutomation(tab, requestedSiteKey) {
  const state = await getCourseState();
  const settings = await chrome.storage.local.get({ enabledSites: {} });
  let siteKey = settings.enabledSites[requestedSiteKey] ? requestedSiteKey : null;
  if (!siteKey) {
    siteKey = Object.entries(state.courseTabBySite).find(([, tabId]) => tabId === tab.id || tabId === tab.openerTabId)?.[0] || null;
  }
  if (siteKey) {
    const enabledSites = { ...settings.enabledSites, [siteKey]: false };
    const courseTabBySite = { ...state.courseTabBySite };
    delete courseTabBySite[siteKey];
    await chrome.storage.local.set({ enabledSites });
    await chrome.storage.session.set({
      courseTabBySite,
      lastCourseTabId: state.lastCourseTabId === state.courseTabBySite[siteKey] ? null : state.lastCourseTabId,
      pausedTabIds: state.pausedTabIds.filter((id) => id !== tab.id)
    });
  }
  await chrome.tabs.sendMessage(tab.id, { type: "VQA_APPLY_STOPPED" }).catch(() => {});
  return { ok: true };
}

async function finishPlayer(siteKey, playerTab) {
  try {
    const dialogResult = await chrome.tabs.sendMessage(playerTab.id, { type: "VQA_CLOSE_PLAYER_DIALOG" }, { frameId: 0 });
    if (dialogResult?.closed) return { ok: true, action: "close-dialog" };
  } catch { /* top frame may not have the content script */ }

  const state = await getCourseState();
  const candidates = [state.courseTabBySite[siteKey], playerTab.openerTabId, state.lastCourseTabId];
  let courseTabId = null;
  for (const candidate of candidates) {
    if (!Number.isInteger(candidate)) continue;
    try {
      await chrome.tabs.get(candidate);
      courseTabId = candidate;
      break;
    } catch { /* stale tab id */ }
  }
  const playerTabId = playerTab.id;
  const action = globalThis.VQAPlayerFlow.finishAction({ hasCloseButton: false, courseTabId, playerTabId });

  try {
    if (action === "close-player-tab") {
      await chrome.tabs.remove(playerTabId);
      const courseTab = await chrome.tabs.get(courseTabId);
      await chrome.windows.update(courseTab.windowId, { focused: true });
      await chrome.tabs.update(courseTabId, { active: true });
      await chrome.tabs.reload(courseTabId);
      return { ok: true, action };
    }

    await chrome.tabs.goBack(playerTabId);
    setTimeout(() => chrome.tabs.reload(playerTabId).catch(() => {}), 1200);
    return { ok: true, action };
  } catch (error) {
    return { ok: false, action, error: error.message };
  }
}

importScripts("player-flow-core.js");
