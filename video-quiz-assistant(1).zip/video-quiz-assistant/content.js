(() => {
  "use strict";

  if (globalThis.__VQA_CONTENT_LOADED__) return;
  globalThis.__VQA_CONTENT_LOADED__ = true;

  const DEFAULTS = {
    enabledSites: {}, playbackRate: 1, actionDelay: 800, autoNext: true,
    autoSubmit: true, showBadge: true, answerRules: "", questionSelector: "",
    optionSelector: "", submitSelector: "", nextSelector: ""
  };
  const COMMON = {
    question: ["[data-question]", ".quiz-question", ".question-item", ".question", ".exam-question", ".subject-node"],
    option: ["label", "[role=radio]", "[role=checkbox]", ".option", ".answer-option", ".choice-item"],
    submit: ["button[type=submit]", ".submit-answer", ".answer-submit", ".quiz-submit"],
    next: [".next-lesson", ".next-section", ".next-video", "button[aria-label*=下一]", "a[aria-label*=下一]"]
  };
  const submitWords = ["提交", "确认", "确定", "交卷", "完成答题"];
  const nextWords = ["下一节", "下一课", "下一个", "继续学习", "继续播放"];
  const closeWords = ["关闭", "关 闭", "退出播放", "返回课程"];
  let config = null;
  let running = false;
  let automationPaused = false;
  let scanTimer = null;
  let observer = null;
  let launchedCourseKey = null;
  let registeredCourseTab = false;
  const handledQuestions = new WeakSet();
  let handledQuizDialogs = new WeakSet();
  const handledVideos = new WeakSet();
  const videoPlayStates = new WeakMap();
  let finishingPlayer = false;

  const normalize = (value) => (value || "").replace(/\s+/g, "").toLowerCase();
  const visible = (el) => Boolean(el && el.isConnected && el.getClientRects().length && getComputedStyle(el).visibility !== "hidden");
  const selectors = (custom, defaults) => custom.trim() ? custom.split(",").map((s) => s.trim()).filter(Boolean) : defaults;

  function parseRules(raw) {
    return raw.split(/\r?\n/).map((line) => {
      const parts = line.split(/\s*(?:=>|→|=)\s*/);
      if (parts.length < 2 || !parts[0].trim() || !parts[1].trim()) return null;
      return { question: normalize(parts.shift()), answers: parts.join("=").split("|").map(normalize).filter(Boolean) };
    }).filter(Boolean);
  }

  function updateBadge(message, kind = "active") {
    if (window.top !== window) return;
    let badge = document.querySelector("#vqa-extension-badge");
    if (!config?.showBadge) {
      badge?.remove();
      return;
    }
    if (!badge) {
      badge = document.createElement("div");
      badge.id = "vqa-extension-badge";
      Object.assign(badge.style, {
        position: "fixed", right: "16px", bottom: "16px", zIndex: "2147483647", display: "flex",
        alignItems: "center", gap: "8px", padding: "7px 8px 7px 12px", borderRadius: "8px",
        color: "white", font: "12px/1.4 system-ui,sans-serif", boxShadow: "0 4px 18px #0004"
      });
      const label = document.createElement("span");
      label.dataset.role = "status";
      const pauseButton = document.createElement("button");
      pauseButton.type = "button";
      pauseButton.dataset.role = "pause";
      pauseButton.title = "暂停自动化";
      pauseButton.textContent = "暂停";
      const stopButton = document.createElement("button");
      stopButton.type = "button";
      stopButton.title = "停止在当前网站运行";
      stopButton.textContent = "停止";
      for (const button of [pauseButton, stopButton]) {
        Object.assign(button.style, {
          border: "1px solid #ffffff66", borderRadius: "5px", padding: "3px 7px",
          color: "white", background: "#ffffff1f", font: "inherit", cursor: "pointer"
        });
      }
      pauseButton.addEventListener("click", () => setPausedFromControl(!automationPaused));
      stopButton.addEventListener("click", stopFromControl);
      badge.append(label, pauseButton, stopButton);
      document.documentElement.appendChild(badge);
    }
    const color = kind === "error" ? "#b91c1c" : kind === "wait" ? "#92400e" : "#166534";
    if (badge.dataset.kind !== kind) {
      badge.dataset.kind = kind;
      badge.style.background = color;
    }
    const label = badge.querySelector('[data-role="status"]');
    const nextText = `自动助手：${message}`;
    if (label.textContent !== nextText) label.textContent = nextText;
    const pauseButton = badge.querySelector('[data-role="pause"]');
    const pauseText = automationPaused ? "继续" : "暂停";
    const pauseTitle = automationPaused ? "继续自动化" : "暂停自动化";
    if (pauseButton.textContent !== pauseText) pauseButton.textContent = pauseText;
    if (pauseButton.title !== pauseTitle) pauseButton.title = pauseTitle;
  }

  function applyPaused(paused) {
    automationPaused = paused;
    if (paused) {
      document.querySelectorAll("video").forEach((video) => video.pause());
      updateBadge("已暂停", "wait");
    } else {
      updateBadge("已继续");
      scheduleScan();
    }
  }

  async function setPausedFromControl(paused) {
    applyPaused(paused);
    try {
      await chrome.runtime.sendMessage({ type: "VQA_SET_TAB_PAUSED", paused });
    } catch { /* local pause still applies */ }
  }

  async function stopFromControl() {
    running = false;
    automationPaused = false;
    updateBadge("已停止", "wait");
    try {
      await chrome.runtime.sendMessage({ type: "VQA_STOP_AUTOMATION", siteKey: location.origin });
    } finally {
      setTimeout(() => document.querySelector("#vqa-extension-badge")?.remove(), 700);
    }
  }

  function findByText(words, root = document) {
    const candidates = root.querySelectorAll("button, a, [role=button], input[type=button], input[type=submit]");
    return [...candidates].find((el) => visible(el) && words.some((word) => normalize(el.innerText || el.value || el.getAttribute("aria-label")).includes(normalize(word))));
  }

  function safeClick(el) {
    if (!visible(el) || el.disabled || el.getAttribute("aria-disabled") === "true") return false;
    el.scrollIntoView({ block: "center", behavior: "smooth" });
    el.click();
    return true;
  }

  function findPlayerPlayButton(video) {
    const root = video.closest([
      "[role=dialog]", ".layui-layer", ".modal", ".el-dialog", ".ant-modal", ".ui-dialog",
      ".video-player", ".player-container", ".prism-player", ".video-js", ".dplayer"
    ].join(",")) || video.parentElement;
    return root ? findByText(["播放", "继续", "play"], root) : null;
  }

  function findCloseButton() {
    const selectors = [
      "[role=dialog] [aria-label*=关闭]", "[role=dialog] .close", ".modal .close",
      ".layui-layer-close", ".ui-dialog-titlebar-close", ".el-dialog__close",
      ".ant-modal-close", "button[title*=关闭]", "a[title*=关闭]"
    ];
    for (const selector of selectors) {
      try {
        const match = [...document.querySelectorAll(selector)].find(visible);
        if (match) return match;
      } catch { /* ignore */ }
    }
    return findByText(closeWords);
  }

  function closestQuizDialog(input) {
    const preferred = input.closest("[role=dialog], .layui-layer, .modal, .el-dialog, .ant-modal, .ui-dialog");
    if (preferred && visible(preferred)) return preferred;
    let node = input.parentElement;
    for (let depth = 0; node && depth < 9; depth += 1, node = node.parentElement) {
      const inputs = node.querySelectorAll("input[type=radio], input[type=checkbox]");
      if (inputs.length >= 2 && findByText(["确定", "提交"], node)) return node;
    }
    return null;
  }

  function findQuizDialog() {
    for (const input of document.querySelectorAll("input[type=radio], input[type=checkbox]")) {
      const dialog = closestQuizDialog(input);
      if (dialog) return dialog;
    }
    return null;
  }

  function findResultDialog() {
    const resultWords = ["正确答案", "回答正确", "回答错误", "答对", "答错"];
    const dialogSelectors = "[role=dialog], .layui-layer, .modal, .el-dialog, .ant-modal, .ui-dialog";
    const dialogs = [...document.querySelectorAll(dialogSelectors)].filter(visible);
    const knownDialog = dialogs.find((dialog) => resultWords.some((word) => normalize(dialog.innerText).includes(normalize(word))) && findByText(["确认", "关闭"], dialog));
    if (knownDialog) return knownDialog;
    const resultButton = findByText(["确认", "关闭"]);
    let node = resultButton?.parentElement;
    for (let depth = 0; node && depth < 9; depth += 1, node = node.parentElement) {
      if (visible(node) && resultWords.some((word) => normalize(node.innerText).includes(normalize(word)))) return node;
    }
    return null;
  }

  function selectQuizOption(input, dialog) {
    if (visible(input)) return safeClick(input);
    let label = input.closest("label");
    if (!label && input.id) {
      try { label = dialog.querySelector(`label[for="${CSS.escape(input.id)}"]`); } catch { /* ignore */ }
    }
    const row = label || input.parentElement;
    if (visible(row)) return safeClick(row);
    input.click();
    return true;
  }

  async function handleInterruptQuiz() {
    const resultDialog = findResultDialog();
    if (resultDialog) {
      const candidates = [...resultDialog.querySelectorAll("button, a, [role=button], input[type=button], input[type=submit]")].filter(visible);
      const preferredText = globalThis.VQAQuiz.resultButtonText(candidates.map((button) => button.innerText || button.value || button.getAttribute("aria-label")));
      const resultButton = (preferredText ? findByText([preferredText], resultDialog) : null) || findCloseButton();
      if (safeClick(resultButton)) {
        handledQuizDialogs = new WeakSet();
        updateBadge("答题结果已处理，继续播放");
        await new Promise((resolve) => setTimeout(resolve, config.actionDelay));
      }
      return true;
    }

    const dialog = findQuizDialog();
    if (!dialog) return false;
    if (handledQuizDialogs.has(dialog)) return true;

    const options = [...dialog.querySelectorAll("input[type=radio], input[type=checkbox]")].filter((option) => !option.disabled);
    const dialogText = normalize(dialog.innerText);
    const type = dialogText.includes("多选") || options.some((option) => option.type === "checkbox") ? "multiple" : "single";
    const count = globalThis.VQAQuiz.selectionCount(type, options.length);
    const indexes = globalThis.VQAQuiz.pickRandomIndexes(options.length, count);
    if (!indexes.length) return true;

    handledQuizDialogs.add(dialog);
    for (const index of indexes) selectQuizOption(options[index], dialog);
    updateBadge(type === "multiple" ? "多选题已随机选择两项" : "单选题已随机选择一项");
    await new Promise((resolve) => setTimeout(resolve, config.actionDelay));
    const submit = findByText(["确定", "提交"], dialog);
    if (safeClick(submit)) updateBadge("答案已提交，等待结果");
    return true;
  }

  function closePlayerDialog() {
    const closeButton = findCloseButton();
    if (!closeButton || !safeClick(closeButton)) return false;
    updateBadge("播放器已关闭，准备下一节");
    launchedCourseKey = null;
    setTimeout(() => location.reload(), 800);
    return true;
  }

  async function finishPlayback() {
    if (finishingPlayer || !config?.autoNext) return;
    finishingPlayer = true;
    updateBadge("视频已结束，等待保存进度");
    await new Promise((resolve) => setTimeout(resolve, Math.max(2500, config.actionDelay * 2)));

    const closeButton = findCloseButton();
    const action = globalThis.VQAPlayerFlow?.finishAction({ hasCloseButton: Boolean(closeButton) });
    if (action === "close-dialog" && closePlayerDialog()) return;

    updateBadge("正在关闭播放器并返回课程列表");
    try {
      const result = await chrome.runtime.sendMessage({ type: "VQA_PLAYER_FINISHED", siteKey: location.origin });
      if (!result?.ok) throw new Error(result?.error || "后台未完成操作");
    } catch (error) {
      finishingPlayer = false;
      updateBadge(`无法关闭播放器：${error.message}`, "error");
    }
  }

  async function handleVideos() {
    let activeVideo = false;
    for (const video of document.querySelectorAll("video")) {
      if (!visible(video)) continue;
      activeVideo = true;
      video.playbackRate = config.playbackRate;
      if (!handledVideos.has(video)) {
        handledVideos.add(video);
        video.addEventListener("ended", finishPlayback);
      }
      let playState = videoPlayStates.get(video);
      if (!playState) {
        playState = { attemptPending: false, fallbackClicked: false, waitingForData: false };
        videoPlayStates.set(video, playState);
      }
      const action = globalThis.VQAPlayerFlow.playbackAction({
        readyState: video.readyState,
        paused: video.paused,
        ended: video.ended,
        attemptPending: playState.attemptPending
      });
      if (action === "wait-for-data") {
        updateBadge("视频加载中…");
        if (!playState.waitingForData) {
          playState.waitingForData = true;
          video.addEventListener("canplay", () => {
            playState.waitingForData = false;
            scheduleScan();
          }, { once: true });
        }
        continue;
      }
      if (action === "try-play") {
        playState.attemptPending = true;
        try {
          await video.play();
          updateBadge(`播放中 · ${config.playbackRate}×`);
        } catch {
          const playButton = playState.fallbackClicked ? null : findPlayerPlayButton(video);
          if (playButton) {
            playState.fallbackClicked = true;
            safeClick(playButton);
          }
          else updateBadge("浏览器要求先手动播放一次", "wait");
        } finally {
          playState.attemptPending = false;
        }
      }
    }
    return activeVideo;
  }

  function findQuestions() {
    const result = new Set();
    for (const selector of selectors(config.questionSelector, COMMON.question)) {
      try { document.querySelectorAll(selector).forEach((el) => visible(el) && result.add(el)); } catch { /* ignore invalid custom selector */ }
    }
    return [...result];
  }

  function findOptions(question) {
    const result = new Set();
    for (const selector of selectors(config.optionSelector, COMMON.option)) {
      try { question.querySelectorAll(selector).forEach((el) => visible(el) && result.add(el)); } catch { /* ignore invalid custom selector */ }
    }
    return [...result];
  }

  function clickMatchingOption(option, answer) {
    if (!normalize(option.innerText || option.textContent || option.value).includes(answer)) return false;
    const input = option.matches("input") ? option : option.querySelector("input[type=radio], input[type=checkbox]");
    return safeClick(input || option);
  }

  async function handleQuestions() {
    const questions = findQuestions();
    const rules = parseRules(config.answerRules);
    if (!rules.length) return questions.length > 0;
    for (const question of questions) {
      if (handledQuestions.has(question)) continue;
      const questionText = normalize(question.innerText || question.textContent);
      const rule = rules.find((item) => questionText.includes(item.question));
      if (!rule) continue;
      const options = findOptions(question);
      const matched = rule.answers.map((answer) => options.some((option) => clickMatchingOption(option, answer))).every(Boolean);
      if (!matched) {
        updateBadge("找到题目，但未匹配到全部选项", "error");
        continue;
      }
      handledQuestions.add(question);
      updateBadge("已选择答案");
      if (config.autoSubmit) {
        await new Promise((resolve) => setTimeout(resolve, config.actionDelay));
        let submit = null;
        for (const selector of selectors(config.submitSelector, COMMON.submit)) {
          try { submit ||= [...question.querySelectorAll(selector), ...document.querySelectorAll(selector)].find(visible); } catch { /* ignore */ }
        }
        submit ||= findByText(submitWords, question) || findByText(submitWords);
        if (safeClick(submit)) {
          updateBadge("答案已提交");
          if (config.autoNext) setTimeout(goNext, config.actionDelay * 2);
        }
      }
    }
    return questions.length > 0;
  }

  async function handleCourseList() {
    if (window.top !== window || !globalThis.VQACourseList) return;
    const entries = [...document.querySelectorAll("tr")].map((row) => {
      const progress = globalThis.VQACourseList.parseProgress(row.innerText || row.textContent);
      if (progress === null || !visible(row)) return null;
      const cells = row.querySelectorAll("td");
      const name = (cells[1]?.innerText || row.innerText || "").trim();
      const playButton = findByText(["播放", "学习", "开始"], row);
      return { row, name, progress, playButton, key: name || String([...row.parentElement.children].indexOf(row)) };
    }).filter(Boolean);

    if (!entries.length) return;
    if (!registeredCourseTab) {
      registeredCourseTab = true;
      try {
        await chrome.runtime.sendMessage({ type: "VQA_REGISTER_COURSE_TAB", siteKey: location.origin });
      } catch {
        registeredCourseTab = false;
        return;
      }
    }
    if (launchedCourseKey) {
      const launched = entries.find((entry) => entry.key === launchedCourseKey);
      if (launched && launched.progress < 100) return;
      launchedCourseKey = null;
    }

    const next = globalThis.VQACourseList.findNextCourse(entries.filter((entry) => entry.playButton));
    if (!next) {
      updateBadge("课程已全部完成");
      return;
    }
    launchedCourseKey = next.key;
    if (safeClick(next.playButton)) updateBadge(`正在打开：${next.name}`);
  }

  function goNext() {
    if (!config?.autoNext) return;
    let next = null;
    for (const selector of selectors(config.nextSelector, COMMON.next)) {
      try { next ||= [...document.querySelectorAll(selector)].find(visible); } catch { /* ignore */ }
    }
    next ||= findByText(nextWords);
    if (safeClick(next)) updateBadge("正在进入下一节");
  }

  function scheduleScan() {
    clearTimeout(scanTimer);
    scanTimer = setTimeout(scan, 250);
  }

  async function scan() {
    if (!running || automationPaused) return;
    const interruptQuizActive = await handleInterruptQuiz();
    const questionActive = interruptQuizActive ? false : await handleQuestions();
    const videoActive = interruptQuizActive || questionActive ? false : await handleVideos();
    if (!interruptQuizActive && !videoActive && !questionActive) await handleCourseList();
  }

  async function start() {
    config = await chrome.storage.local.get(DEFAULTS);
    const directEnabled = Boolean(config.enabledSites[location.origin]);
    let enabled = directEnabled;
    try {
      const state = await chrome.runtime.sendMessage({ type: "VQA_SHOULD_RUN", directEnabled });
      enabled = Boolean(state.enabled);
      automationPaused = Boolean(state.paused);
    } catch { /* extension reload in progress */ }
    running = enabled;
    observer?.disconnect();
    if (!enabled) {
      document.querySelector("#vqa-extension-badge")?.remove();
      return;
    }
    observer = new MutationObserver(scheduleScan);
    observer.observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ["class", "style", "hidden", "disabled"] });
    updateBadge(automationPaused ? "已暂停" : "已启动", automationPaused ? "wait" : "active");
    if (!automationPaused) scan();
  }

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === "VQA_RUN") start();
    if (message?.type === "VQA_CLOSE_PLAYER_DIALOG") sendResponse({ closed: closePlayerDialog() });
    if (message?.type === "VQA_APPLY_PAUSED") applyPaused(Boolean(message.paused));
    if (message?.type === "VQA_APPLY_STOPPED") {
      running = false;
      automationPaused = false;
      document.querySelector("#vqa-extension-badge")?.remove();
    }
  });
  chrome.storage.onChanged.addListener(() => start());
  start();
})();
